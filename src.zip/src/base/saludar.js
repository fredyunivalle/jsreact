
export default function saludar(nombre='Anonimus'){
    return `Hola ${nombre}`
}
