import React from 'react';
import ReactDOM from 'react-dom';
import { MuchosCustomHooks } from './componentes/MuchosCustomHooks';



const divRoot = document.querySelector('#root');


ReactDOM.render( <MuchosCustomHooks/>, divRoot);
