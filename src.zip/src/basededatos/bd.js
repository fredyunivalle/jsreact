let empleados = [
    {
    id: 79854865,
    nombre: 'Fredy',
    ocupa: 'profesor'
    },
    {
        id: 79897465,
        nombre: 'Carlos',
        ocupa: 'contador'
        },
]

export default empleados